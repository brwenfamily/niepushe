<?php
return array (
  'warning_conv_title.1' => 'Inappropriate content',
  'warning_conv_title.2' => 'Inappropriate behavior',
  'warning_conv_title.3' => 'Inappropriate language',
  'warning_conv_title.4' => 'Inappropriate advertising / spam',
);