<?php
return array (
  'forum_type.article' => 'Article',
  'forum_type.discussion' => 'General discussion',
  'forum_type.question' => 'Question',
  'forum_type.suggestion' => 'Suggestion',
);