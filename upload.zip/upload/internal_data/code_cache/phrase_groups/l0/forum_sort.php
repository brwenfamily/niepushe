<?php
return array (
  'forum_sort.first_post_reaction_score' => 'First message reaction score',
  'forum_sort.last_post_date' => 'Last message',
  'forum_sort.post_date' => 'First message',
  'forum_sort.reply_count' => 'Replies',
  'forum_sort.title' => 'Title',
  'forum_sort.view_count' => 'Views',
  'forum_sort.vote_score' => 'Votes',
);