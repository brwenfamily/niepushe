<?php
return array (
  'activity_summary_def.latest_posts' => 'Latest posts',
  'activity_summary_def.latest_threads' => 'Latest threads',
);