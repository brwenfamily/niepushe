<?php
return array (
  'activity_summary_section.1' => '',
  'activity_summary_section.2' => '',
);