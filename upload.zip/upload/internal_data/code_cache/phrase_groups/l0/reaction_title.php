<?php
return array (
  'reaction_title.1' => 'Like',
  'reaction_title.2' => 'Love',
  'reaction_title.3' => 'Haha',
  'reaction_title.4' => 'Wow',
  'reaction_title.5' => 'Sad',
  'reaction_title.6' => 'Angry',
);