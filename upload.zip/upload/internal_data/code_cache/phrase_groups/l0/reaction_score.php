<?php
return array (
  'reaction_score.negative' => 'Negative',
  'reaction_score.neutral' => 'Neutral',
  'reaction_score.positive' => 'Positive',
);