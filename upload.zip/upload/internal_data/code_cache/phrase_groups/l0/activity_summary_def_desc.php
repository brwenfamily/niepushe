<?php
return array (
  'activity_summary_def_desc.latest_posts' => 'Renders a section displaying the latest posts in the activity summary email.',
  'activity_summary_def_desc.latest_threads' => 'Renders a section displaying the latest threads in the activity summary email. Threads can be filtered on various criteria.',
);