<?php
return array (
  'warning_title.1' => 'Inappropriate content',
  'warning_title.2' => 'Inappropriate behavior',
  'warning_title.3' => 'Inappropriate language',
  'warning_title.4' => 'Inappropriate advertising / spam',
);