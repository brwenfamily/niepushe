<?php
return array (
  'thread_prompt.default' => 'Thread title',
);