<?php
return array (
  'emoji_category.activity' => 'Activity',
  'emoji_category.flags' => 'Flags',
  'emoji_category.food' => 'Food',
  'emoji_category.nature' => 'Nature',
  'emoji_category.objects' => 'Objects',
  'emoji_category.people' => 'People',
  'emoji_category.symbols' => 'Symbols',
  'emoji_category.travel' => 'Travel',
);