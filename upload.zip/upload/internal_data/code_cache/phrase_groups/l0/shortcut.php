<?php
return array (
  'shortcut.alerts_menu' => '.',
  'shortcut.bookmarks_menu' => 'b',
  'shortcut.conversations_menu' => ',',
  'shortcut.development_menu' => 'd',
  'shortcut.filter' => 'f',
  'shortcut.forum_actions' => 'a',
  'shortcut.language_chooser' => 'alt+x',
  'shortcut.options' => 'o',
  'shortcut.quick_reply' => 'r',
  'shortcut.search_menu' => '/',
  'shortcut.style_chooser' => 'alt+z',
  'shortcut.visitor_menu' => 'm',
);