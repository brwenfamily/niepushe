<?php
// FROM HASH: 70dec5a815cd0a2b4747ac4553d83872
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('xml_import', $__vars);
	return $__finalCompiled;
}
);